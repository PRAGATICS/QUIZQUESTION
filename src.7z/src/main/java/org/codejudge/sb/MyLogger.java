package org.codejudge.sb;

public class MyLogger {

}
